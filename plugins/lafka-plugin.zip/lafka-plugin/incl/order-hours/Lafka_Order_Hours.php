<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Lafka_Order_Hours {
	public static $lafka_order_hours_options;
	public static $timezone;
	public static $lafka_order_hours_schedule;
	public static $lafka_order_hours_force_override_check;
	public static $lafka_order_hours_force_override_status;
	public static $lafka_order_hours_holidays_calendar;

	public function __construct() {
		self::$lafka_order_hours_options = get_option( 'lafka_order_hours_options' );
		add_action( 'init', array( $this, 'init' ), 99 );
	}

	private function init_order_hours_options(): void {
		self::$timezone                                = '';
		self::$lafka_order_hours_schedule              = self::$lafka_order_hours_options['lafka_order_hours_schedule'] ?? '';
		self::$lafka_order_hours_force_override_check  = self::$lafka_order_hours_options['lafka_order_hours_force_override_check'] ?? false;
		self::$lafka_order_hours_force_override_status = self::$lafka_order_hours_options['lafka_order_hours_force_override_status'] ?? '';
		self::$lafka_order_hours_holidays_calendar     = self::$lafka_order_hours_options['lafka_order_hours_holidays_calendar'] ?? '';

		if ( isset( WC()->session ) ) {
			$lafka_branch_location_id_in_session = WC()->session->get( 'lafka_branch_location' )['branch_id'] ?? null;
			if ( ! empty( $lafka_branch_location_id_in_session ) ) {
				$override_global_order_hours = get_term_meta( $lafka_branch_location_id_in_session, 'lafka_branch_override_order_hours_global', true );
				if ( ! empty( $override_global_order_hours ) ) {
					$branch_timezone                               = get_term_meta( $lafka_branch_location_id_in_session, 'lafka_branch_timezone', true );
					self::$timezone                                = $branch_timezone === 'default' ? '' : $branch_timezone;
					$branch_schedule                               = htmlspecialchars_decode( get_term_meta( $lafka_branch_location_id_in_session, 'lafka_branch_order_hours_schedule', true ) );
					self::$lafka_order_hours_schedule              = empty( $branch_schedule ) ? '' : $branch_schedule;
					self::$lafka_order_hours_force_override_check  = get_term_meta( $lafka_branch_location_id_in_session, 'lafka_branch_order_hours_force_override_check', true );
					self::$lafka_order_hours_force_override_status = get_term_meta( $lafka_branch_location_id_in_session, 'lafka_branch_order_hours_force_override_status', true );
					self::$lafka_order_hours_holidays_calendar     = get_term_meta( $lafka_branch_location_id_in_session, 'lafka_branch_order_hours_holidays_calendar', true );
				}
			}
		}
	}

	public static function get_enabled_dates_for_days_ahead( $days_ahead, $timeslot_duration ): array {
		$current_time  = self::get_order_hours_time();
		$interval      = DateInterval::createFromDateString( '1 day' );
		$enabled_dates = array();

		if ( ! empty( self::$lafka_order_hours_schedule ) ) {
			$schedule_json  = self::$lafka_order_hours_schedule;
			$schedule_array = json_decode( $schedule_json );

			for ( $i = 0; $i <= $days_ahead; $i ++ ) {
				$day_of_the_week_to_check = $current_time->format( 'N' ) - 1;
				if ( ! empty( $schedule_array[ $day_of_the_week_to_check ]->periods ) && ! self::is_day_in_vacation( $current_time ) ) {
					// If is today
					if ( $current_time->format( 'Y-m-d' ) === self::get_order_hours_time()->format( 'Y-m-d' ) ) {
						if ( self::has_future_slots_for_today( $current_time, $timeslot_duration ) ) {
							$enabled_dates[] = $current_time->format( 'Y-m-d' );
						}
					} else {
						$enabled_dates[] = $current_time->format( 'Y-m-d' );
					}
				}
				$current_time->add( $interval );
			}
		}

		return $enabled_dates;
	}

	public static function get_timeslots_for_date( DateTime $date, $timeslot_duration ): array {
		$time_periods = array();

		if ( ! empty( self::$lafka_order_hours_schedule ) ) {
			$schedule_json            = self::$lafka_order_hours_schedule;
			$schedule_array           = json_decode( $schedule_json );
			$day_of_the_week_to_check = $date->format( 'N' ) - 1;
			if ( ! empty( $schedule_array[ $day_of_the_week_to_check ]->periods ) ) {
				$day_periods = $schedule_array[ $day_of_the_week_to_check ]->periods;
				usort( $day_periods, function ( $a, $b ) {
					return strcmp( $a->start, $b->start );
				} );
				foreach ( $day_periods as $period ) {
					if ( $period->end === '00:00' ) {
						$period->end = '24:00';
					}

					while ( 1 ) {
						$entry               = array();
						$curr_start          = $period->start;
						$entry['start']      = $curr_start;
						$current_time        = new DateTime( 'now', $date->getTimezone() );
						$start_time          = DateTime::createFromFormat( 'Y-m-d H:i', $date->format( 'Y-m-d' ) . ' ' . $period->start, $date->getTimezone() );
						$end_time            = DateTime::createFromFormat( 'Y-m-d H:i', $date->format( 'Y-m-d' ) . ' ' . $period->end, $date->getTimezone() );
						$start_plus_timeslot = DateTime::createFromFormat( 'Y-m-d H:i', $date->format( 'Y-m-d' ) . ' ' . $period->start, $date->getTimezone() )->add( DateInterval::createFromDateString( $timeslot_duration . ' minutes' ) );
						if ( $start_plus_timeslot >= $end_time ) {
							$entry['end']   = $period->end;
							$time_periods[] = $entry;
							break;
						} else {
							$entry['end']  = $start_plus_timeslot->format( 'H:i' );
							$period->start = $entry['end'];
							$is_today      = self::get_order_hours_time()->format( 'Y-m-d' ) === $start_plus_timeslot->format( 'Y-m-d' );
							if ( $is_today ) {
								if ( $current_time < $start_plus_timeslot && $current_time <= $start_time ) {
									$time_periods[] = $entry;
								}
							} else {
								$time_periods[] = $entry;
							}
						}
					}
				}
			}
		}

		$response = array();
		foreach ( $time_periods as $time_period ) {
			$response[] = array(
				'id'   => $time_period['start'] . ' - ' . $time_period['end'],
				'text' => $time_period['start'] . ' - ' . $time_period['end']
			);
		}

		return $response;
	}

	public static function get_timezone(): DateTimeZone {
		if ( self::$timezone ) {
			return new DateTimeZone( self::$timezone );
		} else {
			return wp_timezone();
		}
	}

	private static function is_day_in_vacation( DateTime $date ): bool {
		if ( self::$lafka_order_hours_holidays_calendar ) {
			$vacation_dates_array = explode( ', ', self::$lafka_order_hours_holidays_calendar );

			return in_array( $date->format( 'Y-m-d' ), $vacation_dates_array );
		}

		return false;
	}

	private static function has_future_slots_for_today( DateTime $date, $timeslot_duration ): bool {
		if ( ! empty( self::$lafka_order_hours_schedule ) ) {
			$schedule_json            = self::$lafka_order_hours_schedule;
			$schedule_array           = json_decode( $schedule_json );
			$day_of_the_week_to_check = $date->format( 'N' ) - 1;
			if ( ! empty( $schedule_array[ $day_of_the_week_to_check ]->periods ) ) {
				$day_periods = $schedule_array[ $day_of_the_week_to_check ]->periods;
				usort( $day_periods, function ( $a, $b ) {
					return strcmp( $a->start, $b->start );
				} );
				foreach ( $day_periods as $period ) {
					if ( $period->end === '00:00' ) {
						$period->end = '24:00';
					}
					$hours_minutes_array_end = explode( ':', $period->end );
					if ( self::get_order_hours_time()->setTime( $hours_minutes_array_end[0], $hours_minutes_array_end[1] )->sub( DateInterval::createFromDateString( $timeslot_duration . ' minutes' ) ) > $date ) {
						return true;
					}
				}
			}

			return false;
		}

		return false;
	}

	public function init() {
		$this->init_order_hours_options();
		$this->handle_shop_status();

		if ( is_admin() ) {
			include_once( dirname( __FILE__ ) . '/settings/Lafka_Order_Hours_Admin.php' );
			new Lafka_Order_Hours_Admin();
		}
	}

	public static function get_order_hours_time( DateTimeZone $timezone = null ): DateTime {
		if ( empty( $timezone ) ) {
			$temp_timezone = self::get_timezone();
		} else {
			$temp_timezone = $timezone;
		}
		try {

			return new DateTime( 'now', $temp_timezone );
		} catch ( Exception $e ) {
			return new DateTime( '@0' );
		}
	}

	public static function is_shop_open( $branch_timezone = null, $branch_schedule_json = null ): bool {

		// Check if shop status is forced
		if ( self::$lafka_order_hours_force_override_check ) {
			if ( self::$lafka_order_hours_force_override_status ) {
				return true;
			} else {
				return false;
			}
		}

		$current_time = self::get_order_hours_time( $branch_timezone );

		$is_day_in_vacation = self::is_day_in_vacation( $current_time );
		if ( $is_day_in_vacation ) {
			return false;
		}

		$numeric_day_of_the_week = $current_time->format( 'N' );

		// check is it in the open hours periods
		if ( ! isset( self::$lafka_order_hours_schedule ) ) {
			return true;
		}
		if ( empty( $branch_schedule_json ) ) {
			$schedule_json = self::$lafka_order_hours_schedule;
		} else {
			$schedule_json = $branch_schedule_json;
		}

		$schedule_array = json_decode( $schedule_json );
		if ( ! isset( $schedule_array[ $numeric_day_of_the_week - 1 ] ) ) {
			return true;
		}

		$schedule_current_day_of_week = $schedule_array[ $numeric_day_of_the_week - 1 ];
		foreach ( $schedule_current_day_of_week->periods as $period ) {
			$open_time = DateTime::createFromFormat( 'H:i', $period->start, $current_time->getTimezone() );

			if ( $period->end === '00:00' ) {
				$period->end = '24:00';
			}
			$close_time = DateTime::createFromFormat( 'H:i', $period->end, $current_time->getTimezone() );

			if ( $open_time < $current_time && $current_time < $close_time ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * @return object
	 */
	public static function get_shop_status( $branch_timezone = null, $branch_schedule = null ) {
		if ( self::is_shop_open( $branch_timezone, $branch_schedule ) ) {
			return (object) array( 'code' => 'open', 'value' => esc_html__( 'Open', 'lafka-plugin' ) );
		}

		return (object) array( 'code' => 'closed', 'value' => esc_html__( 'Closed', 'lafka-plugin' ) );
	}

	/**
	 * @return bool|DateTime
	 * @throws Exception
	 */
	public static function get_next_opening_time() {
		if ( ! self::is_shop_open() && ! self::$lafka_order_hours_force_override_check ) {

			$current_time            = self::get_order_hours_time();
			$numeric_day_of_the_week = $current_time->format( 'N' );

			$schedule_json = self::$lafka_order_hours_schedule;

			$schedule_array = json_decode( $schedule_json );
			if ( ! isset( $schedule_array[ $numeric_day_of_the_week - 1 ] ) ) {
				return false;
			}

			$counter = 0;
			for ( $day_of_week = $numeric_day_of_the_week - 1; $day_of_week < $day_of_week + 6; $day_of_week ++ ) {
				$weekday_index = $day_of_week;
				if ( $day_of_week > 6 ) {
					$weekday_index = $day_of_week - 7;
				}
				$schedule_day_of_week = $schedule_array[ $weekday_index ];

				foreach ( $schedule_day_of_week->periods as $period ) {
					$open_time = DateTime::createFromFormat( 'H:i', $period->start, Lafka_Order_Hours::get_timezone() )->add( DateInterval::createFromDateString( $counter . ' days' ) );

					if ( $open_time > $current_time ) {
						return $open_time;
					}
				}

				$counter ++;
			}
		}

		return false;
	}

	public function handle_shop_status() {
		if ( ! Lafka_Order_Hours::is_shop_open() ) {

			// Add classes to body
			add_filter( 'body_class', array( $this, 'add_body_class' ) );

			remove_action( 'woocommerce_proceed_to_checkout', 'woocommerce_button_proceed_to_checkout', 20 );
			add_action( 'woocommerce_proceed_to_checkout', array( $this, 'echo_closed_store_message' ), 20 );

			remove_action( 'woocommerce_widget_shopping_cart_buttons', 'woocommerce_widget_shopping_cart_proceed_to_checkout', 20 );
			add_action( 'woocommerce_widget_shopping_cart_buttons', array( $this, 'echo_closed_store_message' ), 20 );

			add_action( 'woocommerce_after_add_to_cart_button', array( $this, 'echo_closed_store_message' ), 99 );
			add_filter( 'woocommerce_order_button_html', array( $this, 'get_closed_store_message' ) );
		}
	}

	public function add_body_class( $classes ) {
		$classes[] = 'lafka-store-closed';

		if ( isset( self::$lafka_order_hours_options['lafka_order_hours_disable_add_to_cart'] ) && self::$lafka_order_hours_options['lafka_order_hours_disable_add_to_cart'] ) {
			$classes[] = 'lafka-disabled-cart-buttons';
		}

		return $classes;
	}

	public function echo_closed_store_message() {
		global $post;

		if ( isset( self::$lafka_order_hours_options['lafka_order_hours_message'] ) && self::$lafka_order_hours_options['lafka_order_hours_message'] ) {
			?>
            <div class="lafka-closed-store-message"><?php echo esc_html( self::$lafka_order_hours_options['lafka_order_hours_message'] ) ?>
				<?php
				if ( isset( self::$lafka_order_hours_options['lafka_order_hours_message_countdown'] ) && self::$lafka_order_hours_options['lafka_order_hours_message_countdown'] ) {
					/** @var DateTime $next_opening_datetime */
					$next_opening_datetime = self::get_next_opening_time();
					if ( $next_opening_datetime ) {
						$countdown_output_format = '{hn}:{mnn}:{snn}';
						$difference              = $next_opening_datetime->diff( self::get_order_hours_time() );
						if ( $difference && $difference->d > 0 ) {
							$countdown_output_format = '{dn} {dl} {hn}:{mnn}:{snn}';
						}
						?>
                        <div class="count_holder_small">
                            <div class="lafka_order_hours_countdown"
                                 data-diff-days="<?php echo esc_attr( $difference->d ); ?>"
                                 data-diff-hours="<?php echo esc_attr( $difference->h ); ?>"
                                 data-diff-minutes="<?php echo esc_attr( $difference->i ); ?>"
                                 data-diff-seconds="<?php echo esc_attr( $difference->s ); ?>"
                                 data-output-format="<?php echo esc_attr( $countdown_output_format ); ?>"
                            ></div>
                            <div class="clear"></div>
                        </div>
						<?php
					}
				}
				?>
            </div>
		<?php }

	}

	public function get_closed_store_message() {
		ob_start();
		$this->echo_closed_store_message();

		return ob_get_clean();
	}
}

new Lafka_Order_Hours();