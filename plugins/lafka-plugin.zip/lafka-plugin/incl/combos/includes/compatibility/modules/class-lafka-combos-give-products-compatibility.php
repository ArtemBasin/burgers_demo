<?php
/**
 * WC_LafkaCombos_Give_Products_Compatibility class
 *
 * @author   Rodrigo Primo <rodrigo@automattic.com>
 * @package  WooCommerce Product Combos
 * @since    5.1.2
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WooCommerce Give Products Integration.
 *
 * @version 5.5.0
 */
class WC_LafkaCombos_Give_Products_Compatibility {

	public static function init() {
		// Whenever a product combo is given to an user make sure all the combined items are included in the order.
		add_action( 'woocommerce_order_given', array( __CLASS__, 'add_combo_product_to_order' ) );
	}

	/**
	 * Loop through the items of an order that was given to an user and re-add combos to the order using WC_LafkaCombos_Order::add_combo_to_order().
	 * Without this code the order will contain only the "container" item without any of the combined items.
	 *
	 * Important: Only works reliably with static combos. WC_LafkaCombos_Order::add_combo_to_order() normally expects a configuration array when a combo has configurable content.
	 *
	 * @param  int  $order_id
	 */
	public static function add_combo_product_to_order( $order_id ) {

		$order                 = wc_get_order( $order_id );
		$items_to_remove       = array();
		$order_contains_combo = false;

		foreach ( $order->get_items( 'line_item' ) as $order_item_id => $order_item ) {

			$product_id  = $order_item->get_product_id();
			$product_qty = $order_item->get_quantity();
			$product     = wc_get_product( $product_id );

			if ( $product && $product->is_type( 'combo' ) ) {

				$items_to_remove[] = $order_item;

				// Re-add the product combo to the order this time adding the combined items.
				WC_LafkaCombos()->order->add_combo_to_order( $product, $order, $product_qty );

				// Remove the original product combo "container" item as it has no combined items associated to it.
				wc_delete_order_item( $order_item_id );

				$order_contains_combo = true;
			}
		}

		if ( ! empty( $items_to_remove ) ) {

			$order->save();

			foreach ( $items_to_remove as $remove_item ) {
				$order->remove_item( $remove_item->get_id() );
				$remove_item->delete();
			}

			$order->save();
		}

		if ( $order_contains_combo ) {
			self::regenerate_download_permissions( $order_id );
		}
	}

	/**
	 * Regenerate download permissions for this order to include the permissions for the combined items if any.
	 *
	 * @param  int  $order_id
	 */
	public static function regenerate_download_permissions( $order_id ) {
		$data_store = WC_Data_Store::load( 'customer-download' );
		$data_store->delete_by_order_id( $order_id );
		wc_downloadable_product_permissions( $order_id, true );
	}
}

WC_LafkaCombos_Give_Products_Compatibility::init();
