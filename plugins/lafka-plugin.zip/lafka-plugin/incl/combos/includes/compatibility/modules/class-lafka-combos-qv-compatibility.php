<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * QuickView Compatibility.
 *
 * @since  4.11.4
 */
class WC_LafkaCombos_QV_Compatibility {

	public static function init() {

		// QuickView support.
		add_action( 'wc_quick_view_enqueue_scripts', array( __CLASS__, 'load_scripts' ) );
		add_filter( 'quick_view_selector', array( __CLASS__, 'qv_selector' ) );
	}

	/**
	 * Load scripts for use by QV on non-product pages.
	 */
	public static function load_scripts() {

		if ( ! is_product() ) {

			WC_LafkaCombos()->display->frontend_scripts();

			wp_enqueue_script( 'wc-add-to-cart-combo' );
			wp_enqueue_style( 'wc-combo-css' );
		}
	}

	/**
	 * Fixes QuickView support for Combos when ajax add-to-cart is active and QuickView operates without a separate button.
	 *
	 * @param   string  $selector
	 * @return  void
	 */
	public static function qv_selector( $selector ) {

		$selector = str_replace( '.product a.product_type_variable', '.product a.product_type_variable, .product a.product_type_combo_input_required', $selector );

		return $selector;
	}
}

WC_LafkaCombos_QV_Compatibility::init();
